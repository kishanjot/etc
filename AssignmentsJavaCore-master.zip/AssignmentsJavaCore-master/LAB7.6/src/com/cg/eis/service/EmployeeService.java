package com.cg.eis.service;

public interface EmployeeService
{
	String findScheme(long salary,String designation);
}