import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlbumuploadsComponent } from './albumuploads.component';

describe('AlbumuploadsComponent', () => {
  let component: AlbumuploadsComponent;
  let fixture: ComponentFixture<AlbumuploadsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlbumuploadsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlbumuploadsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
