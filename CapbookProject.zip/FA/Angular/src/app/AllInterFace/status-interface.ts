import { UserAccount } from '../UserInterface/user-account';
export interface StatusInterface {
	statusMessage:String ;
    likeStatus:number,
    unlikeStatus:number;
	userAccount:UserAccount;
}
