import { UserAccount } from '../UserInterface/user-account';
export interface FriendRequestInterface {
    senderEmailID:string;
    userAccount:UserAccount;
}
