import { Injectable } from '@angular/core';
import { throwError, Observable } from 'rxjs';
import { HttpClient, HttpParams, HttpErrorResponse, HttpRequest, HttpEvent } from '@angular/common/http';
import {map,catchError} from 'rxjs/operators';
import { UserAccount } from '../UserInterface/user-account';
import { PhotoInterface } from '../AllInterFace/photo-interface';
import { StatusInterface } from '../AllInterFace/status-interface';
import { FriendRequestInterface } from '../AllInterface/friend-request-interface';
import { FriendList } from '../AllInterface/friend-list';
import { NotificationInterface } from '../AllInterFace/notification-interface';
@Injectable({
  providedIn: 'root'
})
export class UseraccountService {
  constructor(private httpClient:HttpClient) { }
  public acceptUserDetails(firstName:string,lastName:string,emailID:string,dob:string,gender:string,password:string):Observable<string>{
    var data={
        "emailID":emailID,
        "firstName":firstName,
        "lastName":lastName,
        "password":password,
        "gender":gender,
        "dob": dob
      }
    return this.httpClient.post<string>("http://localhost:1555/acceptUserDetails",data,{}).pipe(catchError(this.handleError));
  }
  public uploadPhotoInStorage(file: File,emailID:string): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('emailID',emailID);
    const req = new HttpRequest('POST', 'http://localhost:1555/upload', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }
  public uploadUpdatePhoto(file: File,emailID:string): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('emailID',emailID);
    formdata.append('flag','1');
    const req = new HttpRequest('POST', 'http://localhost:1555/upload', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }
  public uploadProfilePhoto(file: File,emailID:string): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('emailID',emailID);
    formdata.append('flag','2');
    const req = new HttpRequest('POST', 'http://localhost:1555/upload', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }
  public uploadCoverPhoto(file: File,emailID:string): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    formdata.append('emailID',emailID);
    formdata.append('flag','3');
    const req = new HttpRequest('POST', 'http://localhost:1555/upload', formdata, {
      reportProgress: true,
      responseType: 'text'
    });
    return this.httpClient.request(req);
  }
  public uploadStatus(emailID:string,statusMessage:string): Observable<string> {
    var data={
      "statusMessage":statusMessage,
      "userAccount":{
	    "emailID":emailID
      }
    }
  return this.httpClient.post<string>("http://localhost:1555/uploadStatus",data,{}).pipe(catchError(this.handleError));
  }
  public getAllStatusForAllUser():Observable<StatusInterface[]>{
    return this.httpClient.get<StatusInterface[]>('http://localhost:1555/getAllStatusForAllUser',{}).pipe(catchError(this.handleError));
  }
  public getAllStatusForSingle(emailID:string):Observable<StatusInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<StatusInterface[]>('http://localhost:1555/getAllStatusForSingle',{params:params}).pipe(catchError(this.handleError));
  }
  public getSingleImageForUpdate(emailID:string):Observable<PhotoInterface>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface>('http://localhost:1555/getSingleImageForUpdate',{params:params}).pipe(catchError(this.handleError));
  }
  public getSingleImageForProfile(emailID:string):Observable<PhotoInterface>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface>('http://localhost:1555/getSingleImageForProfile',{params:params}).pipe(catchError(this.handleError));
  }
  public getSingleImageForCover(emailID:string):Observable<PhotoInterface>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface>('http://localhost:1555/getSingleImageForCover',{params:params}).pipe(catchError(this.handleError));
  }
  public getAllImageForUpdate(emailID:string):Observable<PhotoInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface[]>('http://localhost:1555/getAllImagesForUpdate',{params:params}).pipe(catchError(this.handleError));
  }
  public getAllImageForProfile(emailID:string):Observable<PhotoInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface[]>('http://localhost:1555/getAllImagesForProfile',{params:params}).pipe(catchError(this.handleError));
  }
  public getAllImageForCover(emailID:string):Observable<PhotoInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<PhotoInterface[]>('http://localhost:1555/getAllImagesForCover',{params:params}).pipe(catchError(this.handleError));
  }
  public getAllImageFromStorage():Observable<PhotoInterface[]>{
    return this.httpClient.get<PhotoInterface[]>('http://localhost:1555/getAllImageFromStorage',{}).pipe(catchError(this.handleError));
  }
  public getUserAccountDetails(emailID:string):Observable<UserAccount>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<UserAccount>('http://localhost:1555/getUserDetails',{params:params}).pipe(catchError(this.handleError));
  }
  public getNotification(emailID:string):Observable<NotificationInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<NotificationInterface[]>("http://localhost:1555/getAllNotification",{params:params}).pipe(catchError(this.handleError));
  }
  public sendFriendRequest(senderEmailID:string,receiverEmailID:string):Observable<string>{
    var friendRequest={
      "senderEmailID":senderEmailID,
      "userAccount":{
      "emailID":receiverEmailID
      }
    }
   return this.httpClient.post<string>("http://localhost:1555/sendFriendRequest",friendRequest,{}).pipe(catchError(this.handleError));
  }
  public getFriendRequest(emailID:string):Observable<FriendRequestInterface[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<FriendRequestInterface[]>("http://localhost:1555/getFriendRequests",{params:params}).pipe(catchError(this.handleError));
  }
  public acceptFriendRequest(friendEmailID:string,userEmailID:string):Observable<string>{
    var data={
      "friendEmailID":friendEmailID,
      "userAccount":{
       "emailID":userEmailID
      }
    }
    return this.httpClient.post<string>("http://localhost:1555/acceptFriendRequest",data,{}).pipe(catchError(this.handleError));
  }
  public getFriendList(emailID:string):Observable<FriendList[]>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.get<FriendList[]>("http://localhost:1555/getFriendList",{params:params}).pipe(catchError(this.handleError));
  } 
  public acceptExtraUserDetails(emailID:string,school:string,college:string,religion:string,relationshipStatus:string,homeTown:string,currentCity:string,phoneNumber:string,company:string):Observable<UserAccount>{
    var data={
      "emailID":emailID,
      "school": school,
      "college": college,
      "religion": religion,
      "relationshipStatus": relationshipStatus,
      "homeTown": homeTown,
      "currentCity": currentCity,
      "phoneNumber": phoneNumber,
      "company": company,
      }
    return this.httpClient.post<UserAccount>("http://localhost:1555/acceptExtraUserDetails",data,{}).pipe(catchError(this.handleError));
  }
  public deleteUserAccountDetails(emailID:string):Observable<string>{
    let params= new HttpParams();
    params=params.set('emailID',emailID);
    return this.httpClient.delete<string>('http://localhost:1555/deleteUserAccountDetails',{params:params}).pipe(catchError(this.handleError));
  }

  public changePassword(emailID:string,newPassword:string):Observable<string>{    
    var userAccount={
     "emailID":emailID,
     "password":newPassword
   } 
  return this.httpClient.post<string>("http://localhost:1555/changeUserPassword",userAccount,{}).pipe(catchError(this.handleError));
 }
  private handleError(error:any){
    if(error instanceof ErrorEvent){
      console.error('1 An ErrorEvent occurred:',error.error.message);
      return throwError(error.error.message);
    }else if(error instanceof HttpErrorResponse){
      console.error(`2 Backend returned code ${error.status}, body was: ${error.message}`);
      return throwError(` Backend returned code ${error.status}, body was: ${error.message}`);
    }else if(error instanceof TypeError){
      console.error(`3 TypeError has occured ${error.message}, body was ${error.stack}`);
      return throwError(`TypeError has occured ${error.message}, body was ${error.stack}`);
    }
  }
}
