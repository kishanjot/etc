import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TimelineComponent } from './timeline/timeline.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AuthGuard } from './Authguard/auth.guard';
import { UseraccountService } from './Services/useraccount.service';
import {HttpClientModule} from '@angular/common/http';
import { PersonaldetailsComponent } from './personaldetails/personaldetails.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';
import { PhotosComponent } from './photos/photos.component';
import { MyuploadComponent } from './myupload/myupload.component';
import { ReversePipe } from './Pipe/reverse.pipe';
import { AlbumprofileComponent } from './albumprofile/albumprofile.component';
import { AlbumcoverComponent } from './albumcover/albumcover.component';
import { AlbumuploadsComponent } from './albumuploads/albumuploads.component';
import { FriendrequestComponent } from './friendrequest/friendrequest.component';
import { FriendrequestacceptbuttonComponent } from './friendrequestacceptbutton/friendrequestacceptbutton.component';
import { FriendlistComponent } from './friendlist/friendlist.component';
import { FriendprofileComponent } from './friendprofile/friendprofile.component';
import { EditprofileComponent } from './editprofile/editprofile.component';
import { NotificationComponent } from './notification/notification.component';
import { FrienddetailsComponent } from './frienddetails/frienddetails.component'
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    TimelineComponent,
    RegistrationComponent,
    WelcomeComponent,
    PersonaldetailsComponent,
    ChangepasswordComponent,
    DeleteaccountComponent,
    PhotosComponent,
    MyuploadComponent,
    ReversePipe,
    AlbumprofileComponent,
    AlbumcoverComponent,
    AlbumuploadsComponent,
    FriendrequestComponent,
    FriendrequestacceptbuttonComponent,
    FriendlistComponent,
    FriendprofileComponent,
    EditprofileComponent,
    NotificationComponent,
    FrienddetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'frienddetailsComponent',component:FrienddetailsComponent,canActivate:[AuthGuard]},
      {path:'notificationComponent',component:NotificationComponent,canActivate:[AuthGuard]},
      {path:'editprofileComponent',component:EditprofileComponent,canActivate:[AuthGuard]},
      {path:'friendlistComponent',component:FriendlistComponent,canActivate:[AuthGuard]},
      {path:'friendprofileComponent',component:FriendprofileComponent,canActivate:[AuthGuard]},
      {path:'friendrequestComponent',component:FriendrequestComponent,canActivate:[AuthGuard]},
      {path:'albumuploadsComponent',component:AlbumuploadsComponent,canActivate:[AuthGuard]},
      {path:'albumprofileComponent',component:AlbumprofileComponent,canActivate:[AuthGuard]},
      {path:'albumcoverComponent',component:AlbumcoverComponent,canActivate:[AuthGuard]},
      {path:'photosComponent',component:PhotosComponent,canActivate:[AuthGuard]},
      {path:'deleteaccountComponent',component:DeleteaccountComponent,canActivate:[AuthGuard]},
      {path:'changepasswordComponent',component:ChangepasswordComponent,canActivate:[AuthGuard]},
      {path:'personaldetailsComponent',component:PersonaldetailsComponent,canActivate:[AuthGuard]},
      {path:'timelineComponent',component:TimelineComponent,canActivate:[AuthGuard]},
      {path:'registrationComponent',component:RegistrationComponent},
      {path:'homepageComponent',component:HomepageComponent,canActivate:[AuthGuard]},
      {path:'welcomeComponent',component: WelcomeComponent},
      {path:'',redirectTo:'welcomeComponent',pathMatch:'full'},
    ]),
  ],
  providers: [AuthGuard,UseraccountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
