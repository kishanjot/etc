import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { PhotoInterface } from '../AllInterFace/photo-interface';
@Component({
  selector: 'app-albumprofile',
  templateUrl: './albumprofile.component.html',
  styleUrls: ['./albumprofile.component.css']
})
export class AlbumprofileComponent implements OnInit {
  emailID: string;
  allImageForProfile:PhotoInterface[];
  errorProfileImage:string;
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    this.userAccountService.getAllImageForProfile(this.emailID).subscribe(
      x => {
        this.allImageForProfile=x;
      }
      ,
      y=>{
        this.errorProfileImage=y;
      }
     );
  }
  back(): void {
    this.router.navigate(['/photosComponent']);
  }
}
