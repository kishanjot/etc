import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlbumcoverComponent } from './albumcover.component';

describe('AlbumcoverComponent', () => {
  let component: AlbumcoverComponent;
  let fixture: ComponentFixture<AlbumcoverComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlbumcoverComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlbumcoverComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
