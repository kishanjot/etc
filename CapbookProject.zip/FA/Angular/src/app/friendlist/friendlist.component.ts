import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { FriendList } from '../AllInterface/friend-list';
@Component({
  selector: 'app-friendlist',
  templateUrl: './friendlist.component.html',
  styleUrls: ['./friendlist.component.css']
})
export class FriendlistComponent implements OnInit {
  friendListOfCurrentUser:FriendList[];
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.userAccountService.getFriendList(localStorage.getItem('token')).subscribe(
      x=>{
        this.friendListOfCurrentUser=x;      
      },
      y=>{     
      }
    )
  }
  back(): void {
    this.router.navigate(['/timelineComponent']);
  }
}
