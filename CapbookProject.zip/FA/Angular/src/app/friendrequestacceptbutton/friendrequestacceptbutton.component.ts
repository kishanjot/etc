import { Component, OnInit, Input } from '@angular/core';
import { UseraccountService } from '../Services/useraccount.service';
@Component({
  selector: 'app-friendrequestacceptbutton',
  templateUrl: './friendrequestacceptbutton.component.html',
  styleUrls: ['./friendrequestacceptbutton.component.css']
})
export class FriendrequestacceptbuttonComponent implements OnInit {
  @Input() friendEmailID:string;
  userEmailID:string;
  @Input() flag:number;
  constructor(public userAccountService:UseraccountService) { }
  onAcceptFriendRequest(): void{
    this.flag=1;  
    this.userEmailID=localStorage.getItem('token');
    this.userAccountService.acceptFriendRequest(this.friendEmailID,this.userEmailID).subscribe(
      x=>console.log("1"),
      y=>console.log("2")
    );
  }
  isDisabled():boolean{
    if(this.flag!=1){
      return false;
    }
      else
      return true;
  }
  ngOnInit() {
  }
}
