import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { FriendRequestInterface } from '../AllInterface/friend-request-interface';
@Component({
  selector: 'app-friendrequest',
  templateUrl: './friendrequest.component.html',
  styleUrls: ['./friendrequest.component.css']
})
export class FriendrequestComponent implements OnInit {
  fEmailID:string;
  emailID:string;
  receiveFriendRequest:FriendRequestInterface[];
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID=localStorage.getItem("token");
    this.userAccountService.getFriendRequest(this.emailID).subscribe(
      x=>{     
        this.receiveFriendRequest=x;
      },
      y=>{      
      }
    );
  }
  back(): void {  
    this.router.navigate(['/homepageComponent']);
  }
}
