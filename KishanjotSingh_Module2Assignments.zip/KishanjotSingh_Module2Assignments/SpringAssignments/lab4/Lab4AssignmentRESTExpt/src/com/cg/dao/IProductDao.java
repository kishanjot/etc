package com.cg.dao;
import java.util.List;
import com.cg.bean.Product;
public interface IProductDao {
	public List<Product> getAllProducts();
	public void addProduct(Product product);
	public Product searchProduct(int id);
}
