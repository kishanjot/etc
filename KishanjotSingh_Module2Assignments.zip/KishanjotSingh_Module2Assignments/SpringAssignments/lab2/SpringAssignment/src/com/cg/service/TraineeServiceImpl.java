package com.cg.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Login;
import com.cg.bean.Trainee;
import com.cg.dao.TraineeDao;

@Service
public class TraineeServiceImpl implements TraineeService {

	@Autowired
	TraineeDao traineeDao = null;
	
	//getter, setters
	public TraineeDao getTraineeDao() {
		return traineeDao;
	}

	public void setTraineeDao(TraineeDao traineeDao) {
		this.traineeDao = traineeDao;
	}

	@Override
	public boolean isUserExixts(String usn) {
		return traineeDao.isUserExixts(usn);
	}

	@Override
	public Login validateUser(Login login) {
		
		if(login.getUserName().equalsIgnoreCase("admin")&&login.getPassword().equalsIgnoreCase("admin")) {
			
			return login;
		}	
		return null;
	}

	@Override
	public Trainee insertTraineeDetails(Trainee trainee) {
		return null;
	}

	@Override
	public ArrayList<Trainee> getTraineeDetails() {
		return null;
	}

	@Override
	public Trainee deleteTrainee(String usn) {
		return null;
	}

}
