package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="cg_traineeDetails")
public class Trainee {

	@Id
	@Column(name="trainee_id")
	private int traineeId;

	@Column(name="trainee_name", length=25)
	private String traineeName;

	@Column(name="trainee_location", length=25)
	private String traineeLocation;

	@Column(name="trainee_domain", length=25)
	private String traineeDomain;

	public Trainee() {}	

	public Trainee(int traineeId, String traineeName, String traineeLocation, String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;
	}

	public int getTraineeId() {
		return traineeId;
	}

	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}

	@NotEmpty(message="TraineeName Is Mandatory")
	@Pattern(regexp="[A-Z][a-z]*" , message="Name should start with capital and" + 
			" only charcaters allowed")
	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	
	@NotEmpty(message="select the location")
	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
		
	}

	@NotEmpty(message="select the Domain")
	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName + ", traineeLocation="
				+ traineeLocation + ", traineeDomain=" + traineeDomain + "]";
	}
}
