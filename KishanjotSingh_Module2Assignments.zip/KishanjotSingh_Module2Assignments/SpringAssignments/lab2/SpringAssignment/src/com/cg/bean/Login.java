package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="cg_Trainee")
public class Login {
	
	@Id
	@Column(name="user_name", length=20)
	private String userName;
	
	@Column //here password name is same in both DB and here
	private String password;
	
	public Login() {}

	public Login(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}

	@NotEmpty(message="user should be empty")
	@Size(min=5, message="Min 5 characters required in username")
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	@NotEmpty(message="Password Is Mandatory")
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", password=" + password + "]";
	}
}
