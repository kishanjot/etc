package com.cg.bean;

import java.util.ArrayList;

public class SBU {
	private String sbuCode ;
	private String sbuName,sbuHead;
	private ArrayList<Employee>empList;
	
	public SBU() {}

	public String getSbuCode() {
		return sbuCode;
	}
public void setSbuCode(String sbuCode) {
		this.sbuCode = sbuCode;
	}
public ArrayList<Employee> getEmpList() {
		return empList;
	}
public void setEmpList(ArrayList<Employee> empList) {
		this.empList = empList;
	}
public String getSbuName() {
		return sbuName;
	}

	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	public String getSbuHead() {
		return sbuHead;
	}

	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}



	
	
}
