delete from department_master
	where dept_name = 'SALES';