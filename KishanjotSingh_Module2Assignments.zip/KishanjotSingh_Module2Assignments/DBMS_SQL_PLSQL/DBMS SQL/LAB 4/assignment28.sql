select * 
	from all_indexes
		where index_name LIKE '%NO_NAME%';