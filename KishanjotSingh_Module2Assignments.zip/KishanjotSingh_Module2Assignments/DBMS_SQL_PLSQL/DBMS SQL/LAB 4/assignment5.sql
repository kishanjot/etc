alter table customer
	add constraint custid_prim PRIMARY KEY(customerid);